#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define FS_MAGIC 0x56534653U

#define BLOCK_SIZE        4096U
#define INODE_SIZE        128U
#define JOURNAL_BLOCK_IDX    1U
#define JOURNAL_BLOCKS      16U
#define INODE_BLOCKS         2U
#define DATA_BLOCKS         64U
#define INODE_BMAP_IDX     (JOURNAL_BLOCK_IDX + JOURNAL_BLOCKS)      // 17
#define DATA_BMAP_IDX      (INODE_BMAP_IDX + 1U)                    // 18
#define INODE_START_IDX    (DATA_BMAP_IDX + 1U)                     // 19
#define DATA_START_IDX     (INODE_START_IDX + INODE_BLOCKS)        // 21
#define TOTAL_BLOCKS       (DATA_START_IDX + DATA_BLOCKS)           // 85
#define DIRECT_POINTERS     8U                                      

#define DEFAULT_IMAGE "vsfs.img"

#define JOURNAL_MAGIC 0x4A524E4CU

#define REC_DATA   1
#define REC_COMMIT 2

struct superblock {
    uint32_t magic;
    uint32_t block_size;
    uint32_t total_blocks;
    uint32_t inode_count;

    uint32_t journal_block;
    uint32_t inode_bitmap;
    uint32_t data_bitmap;
    uint32_t inode_start;
    uint32_t data_start;

    uint8_t  _pad[128 - 9 * 4];
};

struct inode {
    uint16_t type;
    uint16_t links;
    uint32_t size;
    uint32_t direct[DIRECT_POINTERS];
    uint32_t ctime;
    uint32_t mtime;
    uint8_t _pad[128 - (2 + 2 + 4 + DIRECT_POINTERS * 4 + 4 + 4)];
};

struct dirent {
    uint32_t inode;
    char name[28];
};

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t nbytes_used;
} journal_header_t;

typedef struct __attribute__((packed)) {
    uint16_t type;
    uint16_t size;
} rec_header_t;

static void die(const char *msg) {
    perror(msg);
    exit(1);
}

static off_t blk_off(uint32_t blkno) { return (off_t)blkno * (off_t)BLOCK_SIZE; }

static void read_block(int fd, uint32_t blkno, void *buf) {
    if (pread(fd, buf, BLOCK_SIZE, blk_off(blkno)) != (ssize_t)BLOCK_SIZE) die("pread");
}

static void write_block(int fd, uint32_t blkno, const void *buf) {
    if (pwrite(fd, buf, BLOCK_SIZE, blk_off(blkno)) != (ssize_t)BLOCK_SIZE) die("pwrite");
}

static void read_journal_region(int fd, uint8_t *journal_buf) {
    for (uint32_t i = 0; i < JOURNAL_BLOCKS; i++)
        read_block(fd, JOURNAL_BLOCK_IDX + i, journal_buf + i * BLOCK_SIZE);
}

static void write_journal_region(int fd, const uint8_t *journal_buf) {
    for (uint32_t i = 0; i < JOURNAL_BLOCKS; i++)
        write_block(fd, JOURNAL_BLOCK_IDX + i, journal_buf + i * BLOCK_SIZE);
}

static int bitmap_test(const uint8_t *bm, uint32_t idx) {
    return (bm[idx / 8] >> (idx % 8)) & 1;
}
static void bitmap_set(uint8_t *bm, uint32_t idx) {
    bm[idx / 8] |= (uint8_t)(1U << (idx % 8));
}

static journal_header_t *ensure_journal(uint8_t *jbuf) {
    journal_header_t *jh = (journal_header_t *)jbuf;
    if ((*jh).magic != JOURNAL_MAGIC) {
        memset(jbuf, 0, JOURNAL_BLOCKS * BLOCK_SIZE);
        (*jh).magic = JOURNAL_MAGIC;
        (*jh).nbytes_used = sizeof(journal_header_t);
    }
    if ((*jh).nbytes_used < sizeof(journal_header_t) ||
        (*jh).nbytes_used > JOURNAL_BLOCKS * BLOCK_SIZE) {
        memset(jbuf, 0, JOURNAL_BLOCKS * BLOCK_SIZE);
        (*jh).magic = JOURNAL_MAGIC;
        (*jh).nbytes_used = sizeof(journal_header_t);
    }
    return jh;
}

static void overlay_committed_records(uint8_t *jbuf,
                                      uint8_t *inode_bm,
                                      uint8_t *inode_tbl19,
                                      uint8_t *inode_tbl20,
                                      uint8_t *root_dir21) {
    journal_header_t *jh = (journal_header_t *)jbuf;
    if ((*jh).magic != JOURNAL_MAGIC) return;

    uint32_t off = sizeof(journal_header_t);
    int in_txn = 0;

    typedef struct { uint32_t bno; const uint8_t *img; } pend_t;
    pend_t pend[16];
    int pcnt = 0;

    while (off + sizeof(rec_header_t) <= (*jh).nbytes_used) {
        rec_header_t rh;
        memcpy(&rh, jbuf + off, sizeof(rh));
        if (rh.size < sizeof(rec_header_t) || off + rh.size > (*jh).nbytes_used) break;

        if (rh.type == REC_DATA) {
            uint32_t need = sizeof(rec_header_t) + sizeof(uint32_t) + BLOCK_SIZE;
            if (rh.size != need) break;

            uint32_t bno;
            memcpy(&bno, jbuf + off + sizeof(rec_header_t), sizeof(uint32_t));
            const uint8_t *img = jbuf + off + sizeof(rec_header_t) + sizeof(uint32_t);

            if (pcnt < (int)(sizeof(pend)/sizeof(pend[0]))) {
                pend[pcnt].bno = bno;
                pend[pcnt].img = img;
                pcnt++;
                in_txn = 1;
            }

        } else if (rh.type == REC_COMMIT) {
            if (in_txn) {
                for (int i = 0; i < pcnt; i++) {
                    if (pend[i].bno == INODE_BMAP_IDX) memcpy(inode_bm, pend[i].img, BLOCK_SIZE);
                    if (pend[i].bno == INODE_START_IDX) memcpy(inode_tbl19, pend[i].img, BLOCK_SIZE);
                    if (pend[i].bno == INODE_START_IDX + 1) memcpy(inode_tbl20, pend[i].img, BLOCK_SIZE);
                    if (pend[i].bno == DATA_START_IDX) memcpy(root_dir21, pend[i].img, BLOCK_SIZE);
                }
            }
            pcnt = 0;
            in_txn = 0;
        } else {
            break;
        }

        off += rh.size;
    }
}

static int append_data_record(journal_header_t *jh, uint8_t *jbuf, uint32_t block_no, const uint8_t *block_img) {
    uint32_t JBYTES = JOURNAL_BLOCKS * BLOCK_SIZE;
    uint32_t rec_size = sizeof(rec_header_t) + sizeof(uint32_t) + BLOCK_SIZE;
    if ((*jh).nbytes_used + rec_size > JBYTES) return -1;

    uint32_t off = (*jh).nbytes_used;
    rec_header_t rh = { .type = REC_DATA, .size = (uint16_t)rec_size };
    memcpy(jbuf + off, &rh, sizeof(rh));
    memcpy(jbuf + off + sizeof(rh), &block_no, sizeof(uint32_t));
    memcpy(jbuf + off + sizeof(rh) + sizeof(uint32_t), block_img, BLOCK_SIZE);

    (*jh).nbytes_used += rec_size;
    return 0;
}

static int append_commit(journal_header_t *jh, uint8_t *jbuf) {
    uint32_t JBYTES = JOURNAL_BLOCKS * BLOCK_SIZE;
    uint32_t rec_size = sizeof(rec_header_t);
    if ((*jh).nbytes_used + rec_size > JBYTES) return -1;

    uint32_t off = (*jh).nbytes_used;
    rec_header_t rh = { .type = REC_COMMIT, .size = (uint16_t)rec_size };
    memcpy(jbuf + off, &rh, sizeof(rh));
    (*jh).nbytes_used += rec_size;
    return 0;
}

static int do_install(int fd) {
    uint32_t JBYTES = JOURNAL_BLOCKS * BLOCK_SIZE;
    uint8_t *jbuf = calloc(1, JBYTES);
    if (!jbuf) die("calloc");

    read_journal_region(fd, jbuf);
    journal_header_t *jh = (journal_header_t *)jbuf;

    if ((*jh).magic != JOURNAL_MAGIC) {
        fprintf(stderr, "install: no journal present (magic not set)\n");
        free(jbuf);
        return 1;
    }
    if ((*jh).nbytes_used < sizeof(journal_header_t) || (*jh).nbytes_used > JBYTES) {
        fprintf(stderr, "install: corrupt journal header\n");
        free(jbuf);
        return 1;
    }

    typedef struct { uint32_t bno; uint8_t img[BLOCK_SIZE]; } upd_t;
    upd_t pend[64];
    int pcnt = 0;

    uint32_t off = sizeof(journal_header_t);
    while (off + sizeof(rec_header_t) <= (*jh).nbytes_used) {
        rec_header_t rh;
        memcpy(&rh, jbuf + off, sizeof(rh));
        if (rh.size < sizeof(rec_header_t) || off + rh.size > (*jh).nbytes_used) break;

        if (rh.type == REC_DATA) {
            uint32_t need = sizeof(rec_header_t) + sizeof(uint32_t) + BLOCK_SIZE;
            if (rh.size != need) break;

            uint32_t bno;
            memcpy(&bno, jbuf + off + sizeof(rec_header_t), sizeof(uint32_t));
            memcpy(pend[pcnt].img, jbuf + off + sizeof(rec_header_t) + sizeof(uint32_t), BLOCK_SIZE);
            pend[pcnt].bno = bno;
            pcnt++;

        } else if (rh.type == REC_COMMIT) {
            for (int i = 0; i < pcnt; i++) write_block(fd, pend[i].bno, pend[i].img);
            pcnt = 0;
        } else {
            break;
        }

        off += rh.size;
    }

    (*jh).nbytes_used = sizeof(journal_header_t);
    memset(jbuf + sizeof(journal_header_t), 0, JBYTES - sizeof(journal_header_t));
    write_journal_region(fd, jbuf);

    free(jbuf);
    return 0;
}

static int do_create(int fd, const char *name) {
    if (!name || name[0] == '\0') {
        fprintf(stderr, "create: empty name not allowed\n");
        return 1;
    }
    if (strlen(name) >= 28) {
        fprintf(stderr, "create: name too long (max 27 chars)\n");
        return 1;
    }
    if (!strcmp(name, ".") || !strcmp(name, "..")) {
        fprintf(stderr, "create: invalid name\n");
        return 1;
    }

    uint8_t inode_bm[BLOCK_SIZE], data_bm[BLOCK_SIZE];
    uint8_t inode_tbl19[BLOCK_SIZE], inode_tbl20[BLOCK_SIZE];
    uint8_t root_dir21[BLOCK_SIZE];

    read_block(fd, INODE_BMAP_IDX, inode_bm);
    read_block(fd, DATA_BMAP_IDX, data_bm);
    read_block(fd, INODE_START_IDX, inode_tbl19);
    read_block(fd, INODE_START_IDX + 1, inode_tbl20);
    read_block(fd, DATA_START_IDX, root_dir21);

    uint32_t JBYTES = JOURNAL_BLOCKS * BLOCK_SIZE;
    uint8_t *jbuf = calloc(1, JBYTES);
    if (!jbuf) die("calloc journal");
    read_journal_region(fd, jbuf);
    journal_header_t *jh = ensure_journal(jbuf);

    overlay_committed_records(jbuf, inode_bm, inode_tbl19, inode_tbl20, root_dir21);

    struct dirent *des = (struct dirent *)root_dir21;
    uint32_t entries = BLOCK_SIZE / sizeof(struct dirent);
    for (uint32_t i = 0; i < entries; i++) {
        if (des[i].name[0] == '\0' && des[i].inode == 0) continue;
        if (strncmp(des[i].name, name, sizeof(des[i].name)) == 0) {
            fprintf(stderr, "create: file '%s' already exists\n", name);
            free(jbuf);
            return 1;
        }
    }

    uint32_t new_ino = UINT32_MAX;
    for (uint32_t i = 0; i < 64; i++) {
        if (!bitmap_test(inode_bm, i)) { new_ino = i; break; }
    }
    if (new_ino == UINT32_MAX) {
        fprintf(stderr, "create: no free inodes\n");
        free(jbuf);
        return 1;
    }

    uint32_t free_slot = UINT32_MAX;
    for (uint32_t i = 0; i < entries; i++) {
        if (des[i].inode == 0 && des[i].name[0] == '\0') { free_slot = i; break; }
    }
    if (free_slot == UINT32_MAX) {
        fprintf(stderr, "create: root directory is full\n");
        free(jbuf);
        return 1;
    }

    bitmap_set(inode_bm, new_ino);

    struct inode *inos19 = (struct inode *)inode_tbl19;
    struct inode *inos20 = (struct inode *)inode_tbl20;

    struct inode *root = &inos19[0];
    time_t now = time(NULL);

    (*root).size += sizeof(struct dirent);
    (*root).mtime = (uint32_t)now;

    struct inode newi;
    memset(&newi, 0, sizeof(newi));
    newi.type  = 1;
    newi.links = 1;
    newi.size  = 0;
    newi.ctime = (uint32_t)now;
    newi.mtime = (uint32_t)now;

    if (new_ino < 32) {
        inos19[new_ino] = newi;
    } else {
        inos20[new_ino - 32] = newi;
    }

    des[free_slot].inode = new_ino;
    memset(des[free_slot].name, 0, sizeof(des[free_slot].name));
    strncpy(des[free_slot].name, name, sizeof(des[free_slot].name) - 1);

    if (append_data_record(jh, jbuf, INODE_BMAP_IDX, inode_bm) < 0) {
        fprintf(stderr, "create: journal full\n"); free(jbuf); return 1;
    }
    if (append_data_record(jh, jbuf, INODE_START_IDX, inode_tbl19) < 0) {
        fprintf(stderr, "create: journal full\n"); free(jbuf); return 1;
    }
    if (new_ino >= 32) {
        if (append_data_record(jh, jbuf, INODE_START_IDX + 1, inode_tbl20) < 0) {
            fprintf(stderr, "create: journal full\n"); free(jbuf); return 1;
        }
    }
    if (append_data_record(jh, jbuf, DATA_START_IDX, root_dir21) < 0) {
        fprintf(stderr, "create: journal full\n"); free(jbuf); return 1;
    }
    if (append_commit(jh, jbuf) < 0) {
        fprintf(stderr, "create: journal full\n"); free(jbuf); return 1;
    }

    write_journal_region(fd, jbuf);
    free(jbuf);

    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage:\n");
        fprintf(stderr, "  %s create <name>\n", argv[0]);
        fprintf(stderr, "  %s install\n", argv[0]);
        return 1;
    }

    int fd = open(DEFAULT_IMAGE, O_RDWR);
    if (fd < 0) die("open vsfs.img");

    int rc = 0;

    if (strcmp(argv[1], "install") == 0) {
        rc = do_install(fd);

    } else if (strcmp(argv[1], "create") == 0) {
        if (argc != 3) {
            fprintf(stderr, "usage: %s create <name>\n", argv[0]);
            rc = 1;
        } else {
            rc = do_create(fd, argv[2]);
        }

    } else {
        fprintf(stderr, "unknown command '%s'\n", argv[1]);
        rc = 1;
    }

    close(fd);
    return rc;
}
