-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2025 at 01:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bracu_eats`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `restaurant_id` int(11) NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `menu` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`restaurant_id`, `vendor_id`, `name`, `address`, `menu`) VALUES
(1, NULL, 'Khanas', 'Badda', 'chicken, burger, sandwich'),
(2, NULL, 'Khanas', 'Badda', 'chicken, burger, sandwich'),
(3, NULL, 'Star Kabab', 'Dhanmondi, Road 2, Dhaka', 'Biriyani, Kebab, Paratha, Faluda'),
(4, NULL, 'Kacchi Bhai', 'Banani, Block C, Dhaka', 'Kacchi Biriyani, Beef Rezala, Firni'),
(5, NULL, 'Nando\'s', 'Gulshan 1, Dhaka', 'Peri-Peri Chicken, Garlic Bread, Salads'),
(6, NULL, 'Sbarro', 'Bashundhara City Mall, Dhaka', 'Pizza, Pasta, Garlic Bread'),
(7, NULL, 'BBQ Bangladesh', 'Mohammadpur, Dhaka', 'Grilled Chicken, BBQ Wings, Fried Rice'),
(8, NULL, 'Haji Biriyani', 'Nazira Bazar, Dhaka', 'Mutton Biriyani, Borhani, Zarda'),
(9, NULL, 'Panshi Restaurant', 'Uttara, Sector 4, Dhaka', 'Chicken Curry, Mixed Fried Rice, Chutney'),
(10, NULL, 'Kasturi Restaurant', 'Paltan, Dhaka', 'Hilsha Curry, Lentils, Steamed Rice'),
(11, NULL, 'Sultan\'s Dine', 'Dhanmondi, Road 27, Dhaka', 'Kacchi Biriyani, Borhani, Chicken Roast'),
(12, NULL, 'Gloria Jean\'s Coffees', 'Gulshan 2, Dhaka', 'Coffee, Cakes, Sandwiches');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `stars` tinyint(4) DEFAULT NULL CHECK (`stars` between 1 and 5),
  `text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_id`, `student_id`, `restaurant_id`, `stars`, `text`) VALUES
(23, 12, 1, 4, 'Lorem Ipsum is simply dummy text of the printing and typesetting industryLorem Ipsum is simply dummy text of the printing and typesetting industry'),
(25, 15, 1, 4, 'Good Restaurent'),
(26, 15, 3, 5, 'Shei'),
(27, 15, 3, 3, 'Good');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','vendor','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `role`) VALUES
(1, 'Mushfiqur Rahman Khan', 'mushfiqur.rahman.khan2@g.bracu.ac.bd', '$2y$10$k1rezAxs.acLq5nl8I/vguzf47SKtPzJuf9d40.A8h3.WmONiSJPu', 'student'),
(2, 'Yasin', 'ashfaquesami23@gmail.com', '$2y$10$0Ipan2rOOGR9B5eQttylaeqixI4qwBGLSneTLB.PlZNDLSK2fnWwu', 'student'),
(3, 'Tabassum sultana sajia ', 'sajia123@gmail.com', '$2y$10$tzkrb0UKdon2uO7WeIAkEOf6bPJXlydMPAM0lmbVYElX0UpmaSvai', 'student'),
(4, 'earbwrbrebb', 'WEweg@gmail.com', '$2y$10$byT3Lu0JtSXteRdimZoWQuzDOKKaRPfCdXrcqKLt9pQ2U0xQpJrlS', 'student'),
(5, 'fhWRFUIRG', 'Qefeu@gmail.com', '$2y$10$XSAW1Fq.jGcf/E5.ZSBPWubbonEJgOLlLZPGjZ07OlDZJARRnUGJy', 'student'),
(6, 'Sami ', 'sami123@gmail.com', '$2y$10$dWXo90.4GWOKERg.eJHnZe0VVObiBR6yGI2HkFgLHfJBzbNUzYmbS', 'student'),
(7, 'abrar', 'abrar@gmail.com', '$2y$10$7LH.Gds8EaFFXuT.voLDI.AqKSH3E05axuXsawyL08A4BOVzy1QNu', 'student'),
(8, 'rafi ', 'rafi@gmail.com', '$2y$10$TuwpwYYT/gNDLS9kuwH5Ze5Oj9QuiZssiXGoP9yjaXr9W8rg8.Euy', 'student'),
(9, 'Tamu', 'tamu007@gmil.com', '$2y$10$I4b.Adf7jlvNN/kh7oqRXugUdoNb8Iv6VZuRi.2ZuqwgvHG3Cy/7a', 'student'),
(10, 'Nabila', 'nabilatasneem@gmail.com', '$2y$10$FvCOBG4fFytZvDPjIHAgLOsfXoKPhZLihShsePDqZPLR5frI27Sja', 'student'),
(12, 'bracu', 'bracu@gmail.com', '$2y$10$q/ETgdoyk4.39XaTDO5M1.cr5HgjOxLSNEQ4.CSCaI36wTFzO2fne', 'student'),
(13, 'test', 'test@gmail.com', '$2y$10$KIkA65bSOFxkkrfHIFx01OhizwLZ5xl.UJwgMkMOHcjAT7OBzMoc6', 'student'),
(15, 'try', 'try@gmail.com', '$2y$10$7xsFzo83FbraVJHRXDpVPuHPw1u2cJtQHpzUWEhlACzCBuIWAXuca', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`restaurant_id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `restaurant_id` (`restaurant_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `restaurant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD CONSTRAINT `restaurants_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`restaurant_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
